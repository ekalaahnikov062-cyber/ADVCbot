ADVCbot V2.1 — сборка Windows EXE через GitHub Actions

В архиве:
- ADVCbot.py — исходный код (ввод длины кабеля поддерживает дробные значения через запятую, включая 0,5)
- advcboticon.ico — иконка приложения
- .github/workflows/build-windows.yml — автоматическая сборка EXE на Windows

КАК ПОЛУЧИТЬ ГОТОВЫЙ EXE

1. Войди на https://github.com/ и создай новый репозиторий (New repository).
   Например, назови его ADVCbot. Для простоты можно выбрать Public или Private.
2. Распакуй этот архив на компьютере.
3. Загрузи в созданный репозиторий ВСЕ файлы и папку .github вместе с содержимым.
   Важно: файл workflow должен оказаться по пути .github/workflows/build-windows.yml.
4. Открой вкладку Actions в репозитории.
5. Выбери слева workflow «Build ADVCbot for Windows».
6. Нажми Run workflow → Run workflow.
   (Если загрузка файлов уже запустила сборку автоматически, дождись её завершения.)
7. Открой завершённый запуск с зелёной галочкой.
8. Внизу страницы в разделе Artifacts скачай ADVCbot-Windows-x64.
9. Распакуй скачанный ZIP. Внутри будут ADVCbot.exe и advcboticon.ico.
   Оставь их в одной папке и запускай ADVCbot.exe.

Примечание: GitHub Actions собирает программу на Windows. Первый запуск может занять несколько минут.
